package com.app.mytask;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.app.mytask.Adapters.CryptoListAdapter;
import com.app.mytask.Models.CryptosModel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    RecyclerView cryptosrecycler;
    ArrayList<CryptosModel> cryptosModels;
    CryptoListAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();


        inviews();


    }

    @Override
    protected void onStart() {
        super.onStart();

        getData();
    }

    private void inviews() {

        cryptosrecycler = findViewById(R.id.cryptosrecycler);
        cryptosrecycler.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));
    }

    private void getData()
    {

        StringRequest stringRequest = new StringRequest("https://api.coincap.io/v2/assets", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {


                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray data = jsonObject.getJSONArray("data");
                    cryptosModels = new ArrayList<>();
                    for(int i=0; i<data.length(); i++)
                    {
                        CryptosModel cryptosModel = new CryptosModel();
                        cryptosModel.setSymbol(data.getJSONObject(i).getString("symbol"));
                        cryptosModel.setRank(data.getJSONObject(i).getString("rank"));
                        cryptosModel.setName(data.getJSONObject(i).getString("name"));
                        cryptosModel.setPriceUSD(data.getJSONObject(i).getString("priceUsd"));
                        cryptosModel.setPercentage(data.getJSONObject(i).getString("changePercent24Hr"));
                        cryptosModels.add(cryptosModel);
                    }


                    adapter = new CryptoListAdapter(MainActivity.this,cryptosModels);
                    cryptosrecycler.setAdapter(new CryptoListAdapter(MainActivity.this,cryptosModels));


                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, ""+e, Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(MainActivity.this, ""+error, Toast.LENGTH_SHORT).show();
            }
        });
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(6000,DefaultRetryPolicy.DEFAULT_MAX_RETRIES,DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        Volley.newRequestQueue(this).add(stringRequest);
    }
}