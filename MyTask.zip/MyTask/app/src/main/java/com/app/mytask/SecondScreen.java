package com.app.mytask;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.app.mytask.Adapters.CryptoListAdapter;
import com.app.mytask.Models.CryptosModel;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class SecondScreen extends AppCompatActivity {

    LineChart lineChart;
    ArrayList<Entry> entries;
    public TextView name,symbol,rank,price,percentage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_screen);
        getSupportActionBar().hide();

        name = findViewById(R.id.name);
        symbol = findViewById(R.id.symbol);
        rank = findViewById(R.id.rank);
        price = findViewById(R.id.price);
        percentage = findViewById(R.id.percentage);

        symbol.setText(getIntent().getStringExtra("symbol"));
        rank.setText("("+getIntent().getStringExtra("rank")+")");
        name.setText(getIntent().getStringExtra("name"));
        price.setText(getIntent().getStringExtra("price")+" USD");
        percentage.setText(String.format("%2f", Double.parseDouble(getIntent().getStringExtra("percentage")))+"%");


        lineChart = findViewById(R.id.linechart);

        findViewById(R.id.goback).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });




    }

    @Override
    protected void onStart() {
        super.onStart();

        getData();
    }

    private void getData()
    {

        StringRequest stringRequest = new StringRequest("https://api.coincap.io/v2/assets/bitcoin/history?interval=d1", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {


                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray data = jsonObject.getJSONArray("data");

                    entries = new ArrayList<>();
                    for(int i=0; i<data.length(); i++)
                    {

                        JSONObject jsonObject1 = data.getJSONObject(i);
                        entries.add(new Entry(i,Float.parseFloat(jsonObject1.getString("priceUsd"))));
                        //Float.parseFloat(jsonObject1.getString("priceUsd"));
                    }


                    LineDataSet setCrypto = new LineDataSet(entries, "Crpto");
                    setCrypto.setDrawCircles(false);
                    setCrypto.setColor(Color.RED);
                    lineChart.setData(new LineData(setCrypto));
                    lineChart.notifyDataSetChanged();
                    lineChart.invalidate();


                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(SecondScreen.this, ""+e, Toast.LENGTH_SHORT).show();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(SecondScreen.this, ""+error, Toast.LENGTH_SHORT).show();
            }
        });
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(6000,DefaultRetryPolicy.DEFAULT_MAX_RETRIES,DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
        Volley.newRequestQueue(this).add(stringRequest);
    }

}