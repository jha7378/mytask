package com.app.mytask.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;


import com.app.mytask.Models.CryptosModel;
import com.app.mytask.R;
import com.app.mytask.SecondScreen;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class CryptoListAdapter extends RecyclerView.Adapter<CryptoListAdapter.ViewHolder> {


    Context context;
    ArrayList<CryptosModel> cryptosModels;


    public CryptoListAdapter(Context context, ArrayList<CryptosModel> cryptosModels) {

        this.context = context;
        this.cryptosModels = cryptosModels;

    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.cryptolist_layout, parent, false);
        return new ViewHolder(listItem);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {



        holder.symbol.setText(cryptosModels.get(position).getSymbol());
        holder.rank.setText("("+cryptosModels.get(position).getRank()+")");
        holder.name.setText(cryptosModels.get(position).getName());
        holder.price.setText(cryptosModels.get(position).getPriceUSD()+" USD");
        holder.percentage.setText(String.format("%2f", Double.parseDouble(cryptosModels.get(position).getPercentage()))+"%");


        holder.root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context.startActivity(new Intent(context, SecondScreen.class)
                .putExtra("symbol",cryptosModels.get(position).getSymbol())
                .putExtra("rank",cryptosModels.get(position).getRank())
                .putExtra("name",cryptosModels.get(position).getName())
                .putExtra("price",cryptosModels.get(position).getPriceUSD())
                .putExtra("percentage",cryptosModels.get(position).getPercentage()));
            }
        });



    }

    @Override
    public int getItemCount() {
        return cryptosModels.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {


        public TextView name,symbol,rank,price,percentage;
        public LinearLayout root;


        public ViewHolder(View convertView) {
            super(convertView);

            this.name = convertView.findViewById(R.id.name);
            this.symbol = convertView.findViewById(R.id.symbol);
            this.rank = convertView.findViewById(R.id.rank);
            this.price = convertView.findViewById(R.id.price);
            this.percentage = convertView.findViewById(R.id.percentage);
            this.root = convertView.findViewById(R.id.rootlayout);

        }
    }
}

